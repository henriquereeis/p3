using System;

class Programa
{
    static void Main()
    {
        
        Console.WriteLine("Digite a data de início no formato 'dia DD': ");
        string diaInicio = Console.ReadLine().Split(' ')[1];
        Console.WriteLine("Digite o horário de início no formato 'HH:MM:SS': ");
        string horarioInicio = Console.ReadLine();
        
        
        Console.WriteLine("Digite a data de término no formato 'dia DD': ");
        string diaFim = Console.ReadLine().Split(' ')[1];
        Console.WriteLine("Digite o horário de término no formato 'HH:MM:SS': ");
        string horarioFim = Console.ReadLine();

        
        string dataHoraInicioStr = $"2024-04-{diaInicio}T{horarioInicio}";
        string dataHoraFimStr = $"2024-04-{diaFim}T{horarioFim}";

        
        DateTime dataHoraInicio = DateTime.Parse(dataHoraInicioStr);
        DateTime dataHoraFim = DateTime.Parse(dataHoraFimStr);

        
        TimeSpan duracaoEvento = dataHoraFim - dataHoraInicio;

        Console.WriteLine($"O evento dura {duracaoEvento.Days} dia(s), {duracaoEvento.Hours} hora(s), {duracaoEvento.Minutes} minuto(s) e {duracaoEvento.Seconds} segundo(s).");
    }
}