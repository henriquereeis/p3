using System;

public class Program
{
    public static void Main()
    {
        
        string palavra1 = Console.ReadLine().Trim().ToLower();
        string palavra2 = Console.ReadLine().Trim().ToLower();
        string palavra3 = Console.ReadLine().Trim().ToLower();

        string animal = IdentificarAnimal(palavra1, palavra2, palavra3);

        
        Console.WriteLine(animal);
    }

    public static string IdentificarAnimal(string palavra1, string palavra2, string palavra3)
    {
        if (palavra1 == "vertebrado")
        {
            if (palavra2 == "ave")
            {
                if (palavra3 == "carnivoro")
                {
                    return "aguia";
                }
                else if (palavra3 == "onivoro")
                {
                    return "pomba";
                }
            }
            else if (palavra2 == "mamifero")
            {
                if (palavra3 == "onivoro")
                {
                    return "homem";
                }
                else if (palavra3 == "herbivoro")
                {
                    return "vaca";
                }
            }
        }
        else if (palavra1 == "invertebrado")
        {
            if (palavra2 == "inseto")
            {
                if (palavra3 == "hematofago")
                {
                    return "pulga";
                }
                else if (palavra3 == "herbivoro")
                {
                    return "lagarta";
                }
            }
            else if (palavra2 == "anelideo")
            {
                if (palavra3 == "hematofago")
                {
                    return "sanguessuga";
                }
                else if (palavra3 == "onivoro")
                {
                    return "minhoca";
                }
            }
        }

        return "Animal não identificado";
    }
}