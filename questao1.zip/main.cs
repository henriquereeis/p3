using System;

public class Program
{
    public static void Main()
    {
        string[] notasEntrada = Console.ReadLine().Split(' ');
        float n1 = float.Parse(notasEntrada[0]);
        float n2 = float.Parse(notasEntrada[1]);
        float n3 = float.Parse(notasEntrada[2]);
        float n4 = float.Parse(notasEntrada[3]);

        int[] pesos = { 2, 3, 4, 1 };
        float somaPesos = 10.0f; // 2 + 3 + 4 + 1

        float media = (n1 * pesos[0] + n2 * pesos[1] + n3 * pesos[2] + n4 * pesos[3]) / somaPesos;
        Console.WriteLine($"Media: {media:F1}");

        if (media >= 7.0)
        {
            Console.WriteLine("Aluno aprovado.");
        }
        else if (media < 5.0)
        {
            Console.WriteLine("Aluno reprovado.");
        }
        else
        {
            Console.WriteLine("Aluno em exame.");
            float notaExame = float.Parse(Console.ReadLine());
            Console.WriteLine($"Nota do exame: {notaExame:F1}");
            
            float mediaFinal = (media + notaExame) / 2.0f;

            if (mediaFinal >= 5.0)
            {
                Console.WriteLine("Aluno aprovado.");
            }
            else
            {
                Console.WriteLine("Aluno reprovado.");
            }

            Console.WriteLine($"Media final: {mediaFinal:F1}");
        }
    }
}